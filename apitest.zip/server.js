var express = require('express'),
    app = express(),
    port = process.env.PORT || 3000;
	

app.get('/', function(req, res){
	dburl=process.env.dburl||'not defined';
res.send('Environment Variable:'+' dburl:'+dburl);

})

app.listen(port, function(){
  console.log('Server listening on ', port);
})
